import 'package:flutter/material.dart';

class TextBox extends StatelessWidget {
  IconData iconData;
  String hintText;
  TextEditingController ctrl;
  bool pwd;

  TextBox(this.iconData, this.hintText, this.ctrl, this.pwd);

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(30),
        child: TextField(
          obscureText: pwd,
          controller: ctrl,
          decoration: InputDecoration(
            hintText: 'Enter your text',
            prefixIcon: Icon(iconData),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
          ),
        ));
  }
}
