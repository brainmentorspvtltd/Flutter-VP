import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:todo_demo_example/modules/user/bloc/user_bloc.dart';
import 'package:todo_demo_example/modules/user/pages/login.dart';
import './modules/splash/pages/splash.dart';
import './firebase_options.dart';

Future<void> main() async {
  await dotenv.load(fileName: ".env");
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MaterialApp(
    title: 'To Do App',
    home: SplashScreen(),
    // home: MultiBlocProvider(providers: [
    //   BlocProvider(
    //     create: (c) => UserBloc(),
    //   ),
    // ], child: Login()),
    debugShowCheckedModeBanner: false,
  ));
}
