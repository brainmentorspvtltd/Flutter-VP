class UserState {
  late String name;
  late String email;
  late String image;
  UserState() {
    name = "";
    email = "";
    image = "";
  }
  UserState.init(name, email, image) {
    print("init " + name + " " + email + " " + image);
    this.name = name;
    this.email = email;
    this.image = image;
  }
}
