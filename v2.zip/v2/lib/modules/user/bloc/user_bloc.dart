import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:todo_demo_example/modules/user/bloc/user_state.dart';

import '../../../shared/services/oauth.dart';

abstract class UserEvent {}

class LoginEvent {}

class RegisterEvent {}

class UserBloc extends Bloc<LoginEvent, UserState> {
  UserBloc() : super(UserState()) {
    on<LoginEvent>((event, emit) async {
      print("event .......................");
      print(event);
      OAuth oauth = OAuth();
      UserCredential cred = await oauth.signInWithGoogle();
      print("User Info is ");
      print(cred.user);
      emit(UserState.init(
          cred.user?.displayName, cred.user?.email, cred.user?.photoURL));
    });
  }
}
