import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:todo_demo_example/modules/dashboard/pages/dashboard.dart';
import 'package:todo_demo_example/modules/user/bloc/user_bloc.dart';
import 'package:todo_demo_example/modules/user/bloc/user_state.dart';
import 'package:todo_demo_example/modules/user/model/user_model.dart';
import '../../../shared/services/oauth.dart';
import '../../../shared/widgets/textbox.dart';
import 'package:sign_in_button/sign_in_button.dart';

class Login extends StatelessWidget {
  TextEditingController emailCtrl = TextEditingController();
  TextEditingController pwdCtrl = TextEditingController();
  UserModel _userModel = UserModel();
  late BuildContext ctx;
  _loginWithGoogle() async {
    BlocProvider.of<UserBloc>(ctx).add(LoginEvent());
    print("Hit the Login Event....");
    Navigator.of(ctx)
        .push(MaterialPageRoute(builder: (_) => DashBoard(_userModel)));
    // OAuth oauth = OAuth();
    // UserCredential user = await oauth.signInWithGoogle();
    // print("User Info is ");
    // print(user);
  }

  @override
  Widget build(BuildContext context) {
    this.ctx = context;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [
          Colors.white,
          Colors.yellowAccent,
          Colors.purpleAccent
        ], begin: Alignment.topLeft, end: Alignment.bottomRight)),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              BlocBuilder<UserBloc, UserState>(builder: (ctx, state) {
                print("State is ");
                print(state.email);
                _userModel = UserModel.UserInfo(state.name, state.image);
                return Column(
                  children: [
                    Text("Login User is   ${state.email}  ${state.name}"),
                    state.image.isNotEmpty
                        ? Image.network(state.image)
                        : SizedBox(
                            height: 10,
                          )
                  ],
                );
              }),
              Text(
                'Login',
                style: GoogleFonts.pacifico(fontSize: 40),
              ),
              TextBox(Icons.email, 'Enter EmailId', emailCtrl, false),
              TextBox(Icons.password, 'Enter Password', pwdCtrl, true),
              ElevatedButton(
                onPressed: () {},
                child: Text('Login'),
                style: ElevatedButton.styleFrom(
                    textStyle: TextStyle(fontSize: 20),
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white),
              ),
              SizedBox(height: 20),
              Text(
                'OR',
                style: GoogleFonts.lobster(fontSize: 40),
              ),
              Divider(
                color: Colors.black,
                thickness: 2,
              ),
              SignInButton(
                Buttons.googleDark,
                onPressed: () {
                  _loginWithGoogle();
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
