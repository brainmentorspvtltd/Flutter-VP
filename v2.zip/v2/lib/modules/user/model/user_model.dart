class UserModel {
  late String name;
  late String image;
  UserModel() {}
  UserModel.UserInfo(name, image) {
    this.name = name;
    this.image = image;
  }
}
