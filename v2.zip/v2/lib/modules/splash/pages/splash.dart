import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../user/bloc/user_bloc.dart';
import '/../../modules/user/pages/login.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _isExpanded = true;
  void setAnimationTimer() {
    Timer(Duration(seconds: 3), () {
      setState(() {
        _isExpanded = !_isExpanded;
      });
    });
  }

  void setTimer() {
    Timer(
        Duration(seconds: 5),
        () => Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => BlocProvider(
                      create: (c) => UserBloc(),
                      child: Login(),
                    ))));
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setAnimationTimer();
    setTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
                image: DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage('assets/images/todo.jpg'))),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedContainer(
                  padding: EdgeInsets.all(30),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black),
                  duration: Duration(seconds: 1),
                  width: _isExpanded ? 300.0 : 10.0,
                  height: _isExpanded ? 300.0 : 10.0,
                  // color: _isExpanded ? Colors.blue : Colors.red,
                  alignment: _isExpanded
                      ? Alignment.center
                      : AlignmentDirectional.topCenter,
                  child: AnimatedDefaultTextStyle(
                    duration: Duration(seconds: 1),
                    style: _isExpanded
                        ? GoogleFonts.pacifico(fontSize: 40, color: Colors.red)
                        : TextStyle(
                            fontSize: 10.0,
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                          ),
                    child: Text('Todo App'),
                  ),
                ),
                // Container(
                //   padding: EdgeInsets.all(30),
                //   decoration: BoxDecoration(
                //       borderRadius: BorderRadius.circular(10),
                //       color: Colors.black),
                //   child: Text(
                //     'To Do App',
                //     style:
                //         GoogleFonts.pacifico(fontSize: 40, color: Colors.red),
                //   ),
                // ),
                CircularProgressIndicator(
                  color: Colors.white,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
