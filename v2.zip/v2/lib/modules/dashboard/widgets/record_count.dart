import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class RecordCount extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<int>(
      future: _countDocuments(), // Call function to count documents
      builder: (BuildContext context, AsyncSnapshot<int> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator(); // Show loading indicator while waiting
        } else if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}'); // Show error if any
        } else if (snapshot.hasData) {
          return Text('Task Count: ${snapshot.data}'); // Display the count
        } else {
          return Text('No Data'); // Default case
        }
      },
    );
  }

  Future<int> _countDocuments() async {
    try {
      // Get reference to the Firestore collection
      CollectionReference collectionRef =
          FirebaseFirestore.instance.collection('todo');

      // Query the collection and get documents
      QuerySnapshot querySnapshot = await collectionRef.get();

      // Return the count of documents
      return querySnapshot.size;
    } catch (e) {
      print(e);
      throw e;
    }
  }
}
