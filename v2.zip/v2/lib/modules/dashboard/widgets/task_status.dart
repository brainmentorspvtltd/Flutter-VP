import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:todo_demo_example/modules/dashboard/widgets/record_count.dart';

class TaskStatus extends StatelessWidget {
  const TaskStatus({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      child: Row(
        children: [
          Column(
            children: [
              Container(
                padding: EdgeInsets.all(10),
                child: RecordCount(),
                decoration: BoxDecoration(
                    border: Border(
                        left: BorderSide(
                          color: Colors.blue,
                          width: 5,
                        ),
                        right: BorderSide(color: Colors.grey, width: 1),
                        top: BorderSide(color: Colors.grey, width: 1),
                        bottom: BorderSide(color: Colors.grey, width: 1)),
                    boxShadow: [
                      BoxShadow(color: Colors.white70, spreadRadius: 2)
                    ]),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
