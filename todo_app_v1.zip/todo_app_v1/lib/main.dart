import 'package:flutter/material.dart';
import 'package:todo_app/modules/splash/views/pages/splash_screen.dart';
import 'package:todo_app/modules/user/views/pages/login.dart';

void main() {
  runApp(MaterialApp(
    title: 'To Do App',
    home: Login(),
  ));
}
