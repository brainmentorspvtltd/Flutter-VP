import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sign_in_button/sign_in_button.dart';
import 'package:todo_app/modules/user/bloc/user_bloc.dart';
import 'package:todo_app/modules/user/bloc/user_state.dart';
import 'package:todo_app/shared/widgets/textbox.dart';
import '../../oauth/google_oauth.dart';

class Login extends StatelessWidget {
  late BuildContext ctx;
  _signInWithGoogle() {
    // Event Fire
    BlocProvider.of<UserBloc>(ctx).add(LoginEvent());
  }
  // _signInWithGoogle() async {
  //   UserCredential userCred = await _auth.signInWithGoogle();
  //   print("USer Cred ");
  //   print(userCred);
  // }

  @override
  Widget build(BuildContext context) {
    ctx = context;
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Listener
            BlocBuilder<UserBloc, UserState>(builder: (_, state) {
              return Text('User Info ' + state.name + " " + state.email);
            }),
            Text(
              'Login',
              style: GoogleFonts.pacifico(fontSize: 40),
            ),
            TextBox('Type Email Here', Icons.email, false),
            TextBox('Type Password Here', Icons.password, true),
            ElevatedButton(
              onPressed: () {},
              child: Text('Login'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, foregroundColor: Colors.white),
            ),
            const Divider(
              color: Colors.black,
              thickness: 4,
            ),
            SignInButton(
              Buttons.googleDark,
              onPressed: () {
                _signInWithGoogle();
              },
            )

            // Or Login with Google
          ],
        ),
      ),
    );
  }
}
