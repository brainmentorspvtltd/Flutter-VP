class UserState {
  late String name;
  late String email;
  late String image;
  // UnNamed / Default Constructor
  UserState() {
    name = "";
    email = "";
    image = "";
  }
  // Named Constructor
  UserState.init(this.name, this.email, this.image);
  // UserState.init(String name, String email, String image) {
  //   this.name = name;
  //   this.email = email;
  //   this.image = image;
  // }
}
