// Business Logic
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/modules/user/bloc/user_state.dart';

import '../oauth/google_oauth.dart';

abstract class UserEvent {}

class LoginEvent extends UserEvent {}

class RegisterEvent extends UserEvent {}

class UserBloc extends Bloc<UserEvent, UserState> {
  UserBloc() : super(UserState()) {
    // Listener
    on<LoginEvent>((event, emit) async {
      // Logic  - to bring the user info from OAuth
      GoogleOAuth _auth = GoogleOAuth();
      UserCredential userCred = await _auth.signInWithGoogle();
      User user = userCred.user!;
      // fire the event
      emit(UserState.init(user.displayName!, user.email!, user.photoURL!));
    });
    on<RegisterEvent>((event, emit) {});
  }
}
